# Catchment2Structure (Civil 3D .NET Add-in)

This solution contains a single add-in project:

- `Catchment2Structure.Net8` (Civil 3D 2025/2026+ — AutoCAD .NET 8)

It implements the command:

- `CATCHMENT2STRUCT` — assigns each Civil 3D Catchment to a Pipe Network Structure whose XY position is **inside the catchment boundary**.
  - If multiple structures are inside, the nearest to the catchment **Discharge Point** is chosen.

## 1) Prereqs

- Visual Studio 2022
- .NET 8 SDK (for Civil 3D 2025+ builds)
- Civil 3D installed on the same machine (for the reference DLLs)

## 2) Set your Civil 3D install paths

Edit **`Directory.Build.props`** at the solution root and set:

- `Civil3DNet8Root` to your AutoCAD 2025/2026 base folder (contains `AcDbMgd.dll`)
- `Civil3DNet48Root` to your AutoCAD 2024 base folder

> Civil 3D-managed DLLs are expected in the `C3D` subfolder (e.g. `...\C3D\AeccDbMgd.dll`).

## 3) Build

Open `Catchment2Structure.sln` in Visual Studio and build either project.

On successful build, the solution writes an **Autoloader bundle** to:

- `bundle\Catchment2Structure.bundle`

### Install
Copy the whole folder:

- `bundle\Catchment2Structure.bundle`

to:

- `%AppData%\Autodesk\ApplicationPlugins\Catchment2Structure.bundle`

Then restart Civil 3D.

## 4) Run

In Civil 3D command line:

- `CATCHMENT2STRUCT`

### Notes / options
The command prompts whether to overwrite existing catchment->structure assignments.

## 5) Debugging tip

In Visual Studio:
- Project Properties ➜ Debug ➜ **Start external program**
  - Point to your Civil 3D `acad.exe` (in the same folder as `AcDbMgd.dll`)
- Optional: set command line args like `/nologo`

Then press F5.

---
Generated package ProductCode: 24F3E486-C396-4785-BB94-7CD1D36D8313


## Baked-in Civil 3D path + autoload range

This package is preconfigured for:

- **Civil 3D 2026 install root:** `C:\Program Files\Autodesk\AutoCAD 2026\`
- **Autoload range:** Civil 3D **2025–2026** (`SeriesMin="R25.0" SeriesMax="R25.1"`)

If you want to include Civil 3D 2027+ later, bump `SeriesMax` and rebuild/test.
If you need Civil 3D 2024 or earlier, you must add a .NET Framework build (net48) with the matching RuntimeRequirements.


## Multiple structures inside a catchment

If more than one Structure falls inside a catchment boundary, the command will **highlight the candidate structures** and prompt you to pick the correct one. Press **Enter** to skip that catchment.

## UI

The command now opens a **WPF modal dialog** (dark theme) similar in layout to the provided "Parts List Table" tool.

## Optional polyline conversion

If enabled in the dialog, the command will convert **closed LWPOLYLINEs** on selected layers into **Civil 3D Catchment objects** before assigning catchments to structures.

Catchments are created using `Catchment.Create(name, styleId, catchmentGroupId, surfaceId, boundary)`.

## UI tweaks

- Pipe Network and Target Catchment Group selectors use a dark fill to blend with the dialog.
- Other input fields use a light gray fill.
- Layers grid checkboxes are editable when polyline conversion is enabled.


## Visual Studio requirement
- This solution targets **.NET 8** (Civil 3D 2026). Use **Visual Studio 2022 (17.8+)** with the **.NET Desktop Development** workload installed.
